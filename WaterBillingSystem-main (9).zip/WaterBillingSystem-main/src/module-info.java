module collaborative {
	requires java.xml;
	requires java.desktop;
	requires java.sql;
}