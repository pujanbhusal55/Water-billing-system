package waterBillingSys;

import java.sql.SQLException;

public class Main {
	public static void main(String[] args) throws SQLException {
		Connect c = new Connect();
		Login l = new Login();
	}
}
